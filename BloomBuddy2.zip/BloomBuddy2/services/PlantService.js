import AsyncStorage from '@react-native-async-storage/async-storage';

const PLANTS_STORAGE_KEY = '@plants';
const REMINDERS_STORAGE_KEY = '@reminders';
const SETTINGS_STORAGE_KEY = '@settings';

export const PlantService = {
  // Get all plants
  async getPlants() {
    try {
      const plantsJson = await AsyncStorage.getItem(PLANTS_STORAGE_KEY);
      const plants = plantsJson ? JSON.parse(plantsJson) : [];
      
      // Sort plants by watering urgency
      return plants.sort((a, b) => {
        const daysSinceWateredA = this.getDaysSinceWatered(a);
        const daysSinceWateredB = this.getDaysSinceWatered(b);
        const urgencyA = daysSinceWateredA / a.wateringFrequency;
        const urgencyB = daysSinceWateredB / b.wateringFrequency;
        return urgencyB - urgencyA;
      });
    } catch (error) {
      console.error('Error getting plants:', error);
      return [];
    }
  },

  // Save a new plant
  async savePlant(plant) {
    try {
      if (!plant.name || !plant.wateringFrequency) {
        throw new Error('Plant name and watering frequency are required');
      }

      const plants = await this.getPlants();
      const newPlant = {
        ...plant,
        id: Date.now().toString(),
        lastWatered: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        wateringHistory: [],
      };

      plants.push(newPlant);
      await AsyncStorage.setItem(PLANTS_STORAGE_KEY, JSON.stringify(plants));
      return newPlant;
    } catch (error) {
      console.error('Error saving plant:', error);
      throw error;
    }
  },

  // Update a plant
  async updatePlant(plantId, updatedData) {
    try {
      const plants = await this.getPlants();
      const plantIndex = plants.findIndex(p => p.id === plantId);
      
      if (plantIndex === -1) {
        throw new Error('Plant not found');
      }

      plants[plantIndex] = {
        ...plants[plantIndex],
        ...updatedData,
        updatedAt: new Date().toISOString(),
      };

      await AsyncStorage.setItem(PLANTS_STORAGE_KEY, JSON.stringify(plants));
      return plants[plantIndex];
    } catch (error) {
      console.error('Error updating plant:', error);
      throw error;
    }
  },

  // Delete a plant
  async deletePlant(plantId) {
    try {
      const plants = await this.getPlants();
      const updatedPlants = plants.filter(p => p.id !== plantId);
      
      // Also delete associated reminders
      const reminders = await this.getReminders();
      const updatedReminders = reminders.filter(r => r.plantId !== plantId);
      
      await AsyncStorage.setItem(PLANTS_STORAGE_KEY, JSON.stringify(updatedPlants));
      await AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(updatedReminders));
    } catch (error) {
      console.error('Error deleting plant:', error);
      throw error;
    }
  },

  // Water a plant
  async waterPlant(plantId) {
    try {
      const plants = await this.getPlants();
      const plantIndex = plants.findIndex(p => p.id === plantId);
      
      if (plantIndex === -1) {
        throw new Error('Plant not found');
      }

      const wateringDate = new Date().toISOString();
      plants[plantIndex] = {
        ...plants[plantIndex],
        lastWatered: wateringDate,
        wateringHistory: [
          ...(plants[plantIndex].wateringHistory || []),
          wateringDate
        ],
      };

      await AsyncStorage.setItem(PLANTS_STORAGE_KEY, JSON.stringify(plants));
      return plants[plantIndex];
    } catch (error) {
      console.error('Error watering plant:', error);
      throw error;
    }
  },

  // Get watering history for a plant
  async getWateringHistory(plantId) {
    try {
      const plants = await this.getPlants();
      const plant = plants.find(p => p.id === plantId);
      return plant?.wateringHistory || [];
    } catch (error) {
      console.error('Error getting watering history:', error);
      return [];
    }
  },

  // Get days since last watered
  getDaysSinceWatered(plant) {
    if (!plant.lastWatered) return Infinity;
    const lastWatered = new Date(plant.lastWatered);
    const now = new Date();
    return Math.floor((now - lastWatered) / (1000 * 60 * 60 * 24));
  },

  // Get watering status
  getWateringStatus(plant) {
    const daysSinceWatered = this.getDaysSinceWatered(plant);
    const daysUntilNextWater = plant.wateringFrequency - daysSinceWatered;
    
    if (daysSinceWatered >= plant.wateringFrequency) {
      return {
        status: 'overdue',
        days: daysSinceWatered - plant.wateringFrequency,
      };
    } else if (daysUntilNextWater <= 1) {
      return {
        status: 'due',
        days: daysUntilNextWater,
      };
    } else {
      return {
        status: 'ok',
        days: daysUntilNextWater,
      };
    }
  },

  // Get all reminders
  async getReminders() {
    try {
      const remindersJson = await AsyncStorage.getItem(REMINDERS_STORAGE_KEY);
      const reminders = remindersJson ? JSON.parse(remindersJson) : [];
      
      // Sort reminders by due date
      return reminders.sort((a, b) => {
        const nextWateringA = this.getNextWateringDate(a);
        const nextWateringB = this.getNextWateringDate(b);
        return nextWateringA - nextWateringB;
      });
    } catch (error) {
      console.error('Error getting reminders:', error);
      return [];
    }
  },

  // Save a reminder
  async saveReminder(reminder) {
    try {
      if (!reminder.plantId || !reminder.plantName || !reminder.wateringFrequency) {
        throw new Error('Reminder data is incomplete');
      }

      const reminders = await this.getReminders();
      const newReminder = {
        ...reminder,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        isActive: true,
        lastNotified: null,
        notificationCount: 0,
        nextWateringDate: this.getNextWateringDate(reminder),
        reminderTime: reminder.reminderTime || '09:00', // Default reminder time
        reminderDays: reminder.reminderDays || [1, 2, 3, 4, 5], // Default: Mon-Fri
        snoozeCount: 0,
        snoozeUntil: null,
      };

      reminders.push(newReminder);
      await AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(reminders));
      return newReminder;
    } catch (error) {
      console.error('Error saving reminder:', error);
      throw error;
    }
  },

  // Update a reminder
  async updateReminder(reminderId, updatedData) {
    try {
      const reminders = await this.getReminders();
      const reminderIndex = reminders.findIndex(r => r.id === reminderId);
      
      if (reminderIndex === -1) {
        throw new Error('Reminder not found');
      }

      reminders[reminderIndex] = {
        ...reminders[reminderIndex],
        ...updatedData,
        updatedAt: new Date().toISOString(),
      };

      // Recalculate next watering date if relevant fields changed
      if (updatedData.wateringFrequency || updatedData.lastWatered) {
        reminders[reminderIndex].nextWateringDate = this.getNextWateringDate(reminders[reminderIndex]);
      }

      await AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(reminders));
      return reminders[reminderIndex];
    } catch (error) {
      console.error('Error updating reminder:', error);
      throw error;
    }
  },

  // Delete a reminder
  async deleteReminder(reminderId) {
    try {
      const reminders = await this.getReminders();
      const updatedReminders = reminders.filter(r => r.id !== reminderId);
      await AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(updatedReminders));
    } catch (error) {
      console.error('Error deleting reminder:', error);
      throw error;
    }
  },

  // Get app settings
  async getSettings() {
    try {
      const settingsJson = await AsyncStorage.getItem(SETTINGS_STORAGE_KEY);
      return settingsJson ? JSON.parse(settingsJson) : {
        notifications: true,
        theme: 'light',
        language: 'en',
        measurementUnit: 'metric',
      };
    } catch (error) {
      console.error('Error getting settings:', error);
      return {
        notifications: true,
        theme: 'light',
        language: 'en',
        measurementUnit: 'metric',
      };
    }
  },

  // Update app settings
  async updateSettings(newSettings) {
    try {
      const currentSettings = await this.getSettings();
      const updatedSettings = {
        ...currentSettings,
        ...newSettings,
        updatedAt: new Date().toISOString(),
      };
      await AsyncStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(updatedSettings));
      return updatedSettings;
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    }
  },

  // Get next watering date for a reminder
  getNextWateringDate(reminder) {
    const lastWatered = new Date(reminder.lastWatered || reminder.createdAt);
    const nextWatering = new Date(lastWatered);
    nextWatering.setDate(nextWatering.getDate() + reminder.wateringFrequency);
    return nextWatering.toISOString();
  },

  // Get reminder status
  getReminderStatus(reminder) {
    const now = new Date();
    const nextWatering = new Date(reminder.nextWateringDate);
    const daysUntilWatering = Math.floor((nextWatering - now) / (1000 * 60 * 60 * 24));

    if (daysUntilWatering < 0) {
      return {
        status: 'overdue',
        days: Math.abs(daysUntilWatering),
      };
    } else if (daysUntilWatering === 0) {
      return {
        status: 'due',
        days: 0,
      };
    } else {
      return {
        status: 'scheduled',
        days: daysUntilWatering,
      };
    }
  },

  // Snooze a reminder
  async snoozeReminder(reminderId, hours = 24) {
    try {
      const reminders = await this.getReminders();
      const reminderIndex = reminders.findIndex(r => r.id === reminderId);
      
      if (reminderIndex === -1) {
        throw new Error('Reminder not found');
      }

      const snoozeUntil = new Date();
      snoozeUntil.setHours(snoozeUntil.getHours() + hours);

      reminders[reminderIndex] = {
        ...reminders[reminderIndex],
        snoozeCount: (reminders[reminderIndex].snoozeCount || 0) + 1,
        snoozeUntil: snoozeUntil.toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(reminders));
      return reminders[reminderIndex];
    } catch (error) {
      console.error('Error snoozing reminder:', error);
      throw error;
    }
  },

  // Mark reminder as notified
  async markReminderNotified(reminderId) {
    try {
      const reminders = await this.getReminders();
      const reminderIndex = reminders.findIndex(r => r.id === reminderId);
      
      if (reminderIndex === -1) {
        throw new Error('Reminder not found');
      }

      reminders[reminderIndex] = {
        ...reminders[reminderIndex],
        lastNotified: new Date().toISOString(),
        notificationCount: (reminders[reminderIndex].notificationCount || 0) + 1,
        updatedAt: new Date().toISOString(),
      };

      await AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(reminders));
      return reminders[reminderIndex];
    } catch (error) {
      console.error('Error marking reminder as notified:', error);
      throw error;
    }
  },

  // Get reminders that need notification
  async getDueReminders() {
    try {
      const reminders = await this.getReminders();
      const now = new Date();
      
      return reminders.filter(reminder => {
        if (!reminder.isActive) return false;
        
        const nextWatering = new Date(reminder.nextWateringDate);
        const isDue = nextWatering <= now;
        
        // Check if reminder is snoozed
        if (reminder.snoozeUntil) {
          const snoozeUntil = new Date(reminder.snoozeUntil);
          if (snoozeUntil > now) return false;
        }
        
        return isDue;
      });
    } catch (error) {
      console.error('Error getting due reminders:', error);
      return [];
    }
  },
}; 