import 'react-native-gesture-handler'; // <<< ต้องอยู่บนสุด!!
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import AddPlantScreen from './screens/AddPlantScreen';
import ReminderScreen from './screens/ReminderScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerStyle: { backgroundColor: '#a3d9a5' }, // เขียวพาสเทลน่ารัก
          headerTintColor: '#fff',
          headerTitleAlign: 'center',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'My Plants' }} />
        <Stack.Screen name="AddPlant" component={AddPlantScreen} options={{ title: 'Add a Plant' }} />
        <Stack.Screen name="Reminder" component={ReminderScreen} options={{ title: 'Reminders' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
