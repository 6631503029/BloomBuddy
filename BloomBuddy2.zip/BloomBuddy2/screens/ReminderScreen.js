import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, Pressable, Alert, ActivityIndicator, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { PlantService } from '../services/PlantService';

export default function ReminderScreen({ navigation }) {
  const [reminders, setReminders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadReminders();
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadReminders();
    });

    return unsubscribe;
  }, [navigation]);

  const loadReminders = async () => {
    try {
      setLoading(true);
      const loadedReminders = await PlantService.getReminders();
      setReminders(loadedReminders);
    } catch (error) {
      console.error('Error loading reminders:', error);
      Alert.alert('Error', 'Failed to load reminders');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleSnooze = async (reminderId) => {
    try {
      await PlantService.snoozeReminder(reminderId);
      await loadReminders();
      Alert.alert('Success', 'Reminder snoozed for 24 hours');
    } catch (error) {
      console.error('Error snoozing reminder:', error);
      Alert.alert('Error', 'Failed to snooze reminder');
    }
  };

  const handleMarkAsDone = async (reminderId) => {
    try {
      await PlantService.markReminderNotified(reminderId);
      await loadReminders();
      Alert.alert('Success', 'Reminder marked as done');
    } catch (error) {
      console.error('Error marking reminder:', error);
      Alert.alert('Error', 'Failed to mark reminder');
    }
  };

  const handleDeleteReminder = async (reminderId) => {
    Alert.alert(
      'Delete Reminder',
      'Are you sure you want to delete this reminder?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await PlantService.deleteReminder(reminderId);
              await loadReminders();
              Alert.alert('Success', 'Reminder deleted successfully');
            } catch (error) {
              console.error('Error deleting reminder:', error);
              Alert.alert('Error', 'Failed to delete reminder');
            }
          },
        },
      ]
    );
  };

  const renderReminder = ({ item }) => {
    const status = PlantService.getReminderStatus(item);
    const nextWatering = new Date(item.nextWateringDate);
    const isSnoozed = item.snoozeUntil && new Date(item.snoozeUntil) > new Date();

    return (
      <View style={[
        styles.card,
        status.status === 'overdue' && styles.cardAlert,
        status.status === 'due' && styles.cardWarning,
        isSnoozed && styles.cardSnoozed
      ]}>
        <View style={styles.header}>
          <Text style={styles.plantName}>{item.plantName}</Text>
          <View style={styles.statusContainer}>
            {status.status === 'overdue' ? (
              <Text style={styles.alertText}>{status.days} days overdue</Text>
            ) : status.status === 'due' ? (
              <Text style={styles.warningText}>Due today</Text>
            ) : (
              <Text style={styles.scheduledText}>In {status.days} days</Text>
            )}
          </View>
        </View>

        <View style={styles.details}>
          <Text style={styles.detailText}>
            Water every {item.wateringFrequency} days
          </Text>
          <Text style={styles.detailText}>
            Next watering: {nextWatering.toLocaleDateString()}
          </Text>
          {isSnoozed && (
            <Text style={styles.snoozeText}>
              Snoozed until {new Date(item.snoozeUntil).toLocaleTimeString()}
            </Text>
          )}
        </View>

        <View style={styles.actions}>
          <Pressable 
            style={({ pressed }) => [
              styles.actionButton,
              styles.snoozeButton,
              pressed && styles.buttonPressed
            ]}
            onPress={() => handleSnooze(item.id)}
          >
            <Text style={styles.actionButtonText}>Snooze</Text>
          </Pressable>

          <Pressable 
            style={({ pressed }) => [
              styles.actionButton,
              styles.doneButton,
              pressed && styles.buttonPressed
            ]}
            onPress={() => handleMarkAsDone(item.id)}
          >
            <Text style={styles.actionButtonText}>Done</Text>
          </Pressable>

          <Pressable 
            style={({ pressed }) => [
              styles.actionButton,
              styles.deleteButton,
              pressed && styles.buttonPressed
            ]}
            onPress={() => handleDeleteReminder(item.id)}
          >
            <Text style={styles.actionButtonText}>Delete</Text>
          </Pressable>
        </View>
      </View>
    );
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadReminders();
  };

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#81c784" />
        <Text style={styles.loadingText}>Loading reminders...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Reminders</Text>
      </View>

      {reminders.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="notifications-outline" size={64} color="#81c784" />
          <Text style={styles.emptyText}>No reminders yet!</Text>
          <Text style={styles.emptySubtext}>Add plants to get watering reminders 🌱</Text>
        </View>
      ) : (
        <FlatList
          data={reminders}
          keyExtractor={(item) => item.id}
          renderItem={renderReminder}
          contentContainerStyle={{ paddingBottom: 20 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={['#81c784']}
              tintColor="#81c784"
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fdfdfd',
  },
  header: {
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#333',
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  cardAlert: {
    borderColor: '#ffccbc',
    borderWidth: 1,
    backgroundColor: '#fff3e0',
  },
  cardWarning: {
    borderColor: '#ffe0b2',
    borderWidth: 1,
    backgroundColor: '#fff8e1',
  },
  cardSnoozed: {
    borderColor: '#e0e0e0',
    borderWidth: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  plantName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  statusContainer: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  alertText: {
    color: '#d32f2f',
    fontWeight: '500',
  },
  warningText: {
    color: '#f57c00',
    fontWeight: '500',
  },
  scheduledText: {
    color: '#4caf50',
    fontWeight: '500',
  },
  details: {
    marginBottom: 12,
  },
  detailText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  snoozeText: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
    marginTop: 4,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 8,
  },
  actionButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  snoozeButton: {
    backgroundColor: '#e3f2fd',
  },
  doneButton: {
    backgroundColor: '#e8f5e9',
  },
  deleteButton: {
    backgroundColor: '#ffebee',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  buttonPressed: {
    opacity: 0.8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fdfdfd',
  },
  loadingText: {
    fontSize: 16,
    color: '#666',
    marginTop: 12,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 24,
    fontWeight: '600',
    color: '#333',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});
