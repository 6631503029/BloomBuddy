import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, Pressable, Image, Animated, Alert, ActivityIndicator, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { PlantService } from '../services/PlantService';

export default function HomeScreen({ navigation }) {
  const [plants, setPlants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [scaleAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    loadPlants();
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadPlants();
    });

    return unsubscribe;
  }, [navigation]);

  const loadPlants = async () => {
    try {
      setLoading(true);
      const loadedPlants = await PlantService.getPlants();
      setPlants(loadedPlants);
    } catch (error) {
      console.error('Error loading plants:', error);
      Alert.alert('Error', 'Failed to load plants');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleWaterPlant = async (plantId) => {
    try {
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 0.95,
          duration: 100,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 100,
          useNativeDriver: true,
        }),
      ]).start();

      await PlantService.waterPlant(plantId);
      await loadPlants();
      Alert.alert('Success', 'Plant has been watered! 🌱');
    } catch (error) {
      console.error('Error watering plant:', error);
      Alert.alert('Error', 'Failed to water plant');
    }
  };

  const handleDeletePlant = async (plantId) => {
    Alert.alert(
      'Delete Plant',
      'Are you sure you want to delete this plant?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await PlantService.deletePlant(plantId);
              await loadPlants();
              Alert.alert('Success', 'Plant deleted successfully');
            } catch (error) {
              console.error('Error deleting plant:', error);
              Alert.alert('Error', 'Failed to delete plant');
            }
          },
        },
      ]
    );
  };

  const renderPlant = ({ item }) => {
    const wateringStatus = PlantService.getWateringStatus(item);
    const daysSinceWatered = PlantService.getDaysSinceWatered(item);

    return (
      <Animated.View style={[
        styles.card,
        wateringStatus.status === 'overdue' && styles.cardAlert,
        wateringStatus.status === 'due' && styles.cardWarning
      ]}>
        {item.image ? (
          <Image source={{ uri: item.image }} style={styles.image} />
        ) : (
          <View style={styles.placeholderImage}>
            <Text style={styles.placeholderText}>🌱</Text>
          </View>
        )}
        <View style={styles.info}>
          <View style={styles.headerRow}>
            <Text style={styles.plantName}>{item.name}</Text>
            <View style={styles.actionButtons}>
              <Pressable 
                style={({ pressed }) => [
                  styles.waterButton,
                  pressed && styles.buttonPressed
                ]}
                onPress={() => handleWaterPlant(item.id)}
              >
                <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
                  <Ionicons name="water" size={24} color="#4caf50" />
                </Animated.View>
              </Pressable>
              <Pressable 
                style={({ pressed }) => [
                  styles.deleteButton,
                  pressed && styles.buttonPressed
                ]}
                onPress={() => handleDeletePlant(item.id)}
              >
                <Ionicons name="trash-outline" size={24} color="#f44336" />
              </Pressable>
            </View>
          </View>
          <Text style={styles.plantType}>{item.type} • {item.location}</Text>
          <Text style={styles.waterText}>
            Water every {item.wateringFrequency} days
          </Text>
          <View style={styles.statusContainer}>
            {wateringStatus.status === 'overdue' ? (
              <Text style={styles.alertText}>💧 {daysSinceWatered - item.wateringFrequency} days overdue!</Text>
            ) : wateringStatus.status === 'due' ? (
              <Text style={styles.warningText}>💧 Due today!</Text>
            ) : (
              <Text style={styles.nextWaterText}>
                Next watering in {wateringStatus.days} days
              </Text>
            )}
          </View>
          {item.notes && (
            <Text style={styles.notes} numberOfLines={2}>
              📝 {item.notes}
            </Text>
          )}
        </View>
      </Animated.View>
    );
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadPlants();
  };

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#81c784" />
        <Text style={styles.loadingText}>Loading plants...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Plants</Text>
        <Pressable 
          style={({ pressed }) => [
            styles.settingsButton,
            pressed && styles.buttonPressed
          ]}
          onPress={() => navigation.navigate('Settings')}
        >
          <Ionicons name="settings-outline" size={24} color="#333" />
        </Pressable>
      </View>

      {plants.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="leaf-outline" size={64} color="#81c784" />
          <Text style={styles.emptyText}>No plants yet!</Text>
          <Text style={styles.emptySubtext}>Add your first plant to get started 🌱</Text>
        </View>
      ) : (
        <FlatList
          data={plants}
          keyExtractor={(item) => item.id}
          renderItem={renderPlant}
          contentContainerStyle={{ paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={['#81c784']}
              tintColor="#81c784"
            />
          }
        />
      )}

      <View style={styles.buttonContainer}>
        <Pressable 
          style={({ pressed }) => [
            styles.button,
            pressed && styles.buttonPressed
          ]}
          onPress={() => navigation.navigate('AddPlant')}
        >
          <Text style={styles.buttonText}>Add Plant</Text>
        </Pressable>

        <Pressable 
          style={({ pressed }) => [
            styles.buttonOutline,
            pressed && styles.buttonPressed
          ]}
          onPress={() => navigation.navigate('Reminder')}
        >
          <Text style={styles.buttonOutlineText}>View Reminders</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: '#fdfdfd' 
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: { 
    fontSize: 32, 
    fontWeight: '700', 
    color: '#333',
    marginBottom: 20 
  },
  settingsButton: {
    padding: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 16,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 5,
    alignItems: 'center',
    transform: [{ scale: 1 }],
  },
  cardAlert: {
    borderColor: '#ffccbc',
    borderWidth: 2,
    backgroundColor: '#fff3e0'
  },
  cardWarning: {
    borderColor: '#ffe0b2',
    borderWidth: 2,
    backgroundColor: '#fff8e1'
  },
  image: {
    width: 70,
    height: 70,
    borderRadius: 35,
    marginRight: 15
  },
  placeholderImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#e0f2f1',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15
  },
  placeholderText: {
    fontSize: 30
  },
  info: {
    flex: 1
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  plantName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333'
  },
  plantType: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  waterText: {
    fontSize: 14,
    color: '#777',
    marginTop: 4
  },
  statusContainer: {
    marginTop: 8,
  },
  nextWaterText: {
    fontSize: 14,
    color: '#4caf50',
    fontWeight: '500'
  },
  alertText: {
    fontSize: 14,
    color: '#d32f2f',
    fontWeight: 'bold'
  },
  warningText: {
    fontSize: 14,
    color: '#f57c00',
    fontWeight: 'bold'
  },
  notes: {
    fontSize: 12,
    color: '#666',
    marginTop: 8,
    fontStyle: 'italic',
  },
  waterButton: {
    padding: 8,
    borderRadius: 20,
    backgroundColor: '#e8f5e9',
  },
  deleteButton: {
    padding: 8,
    borderRadius: 20,
    backgroundColor: '#ffebee',
  },
  buttonContainer: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
  },
  buttonPressed: {
    transform: [{ scale: 0.95 }],
    opacity: 0.8,
  },
  button: {
    backgroundColor: '#81c784',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  buttonOutline: {
    borderWidth: 1,
    borderColor: '#81c784',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  buttonOutlineText: {
    color: '#81c784',
    fontSize: 16,
    fontWeight: '500',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fdfdfd',
  },
  loadingText: {
    fontSize: 18,
    color: '#666',
    marginTop: 10,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 24,
    fontWeight: '600',
    color: '#333',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});
