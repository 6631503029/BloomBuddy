import React, { useState } from 'react';
import { View, TextInput, Text, StyleSheet, Pressable, Image, Switch, ScrollView, Alert, Animated, ActivityIndicator } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { Ionicons } from '@expo/vector-icons';
import { PlantService } from '../services/PlantService';

export default function AddPlantScreen({ navigation }) {
  const [plantName, setPlantName] = useState('');
  const [wateringFrequency, setWateringFrequency] = useState('');
  const [image, setImage] = useState(null);
  const [plantDate, setPlantDate] = useState(new Date());
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [reminder, setReminder] = useState(true);
  const [plantType, setPlantType] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [scaleAnim] = useState(new Animated.Value(1));
  const [loading, setLoading] = useState(false);

  const handleAddPlant = async () => {
    if (!plantName || !wateringFrequency) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      const newPlant = {
        name: plantName,
        wateringFrequency: parseInt(wateringFrequency),
        image,
        plantDate: plantDate.toISOString(),
        type: plantType,
        location,
        notes,
      };

      const savedPlant = await PlantService.savePlant(newPlant);
      
      if (reminder) {
        await PlantService.saveReminder({
          plantId: savedPlant.id,
          plantName: plantName,
          wateringFrequency: parseInt(wateringFrequency),
          lastWatered: new Date().toISOString(),
          reminderTime: '09:00', // Default reminder time
          reminderDays: [1, 2, 3, 4, 5], // Default: Mon-Fri
        });
      }

      Alert.alert('Success', 'Plant added successfully! 🌱');
      navigation.goBack();
    } catch (error) {
      console.error('Error adding plant:', error);
      Alert.alert('Error', 'Failed to add plant');
    } finally {
      setLoading(false);
    }
  };

  const pickImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Please grant camera roll permissions to add plant photos');
        return;
      }

      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 0.95,
          duration: 100,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 100,
          useNativeDriver: true,
        }),
      ]).start();

      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });

      if (!result.canceled) {
        setImage(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick image');
    }
  };

  const showDatePicker = () => setDatePickerVisibility(true);
  const hideDatePicker = () => setDatePickerVisibility(false);
  const handleConfirmDate = (date) => {
    setPlantDate(date);
    hideDatePicker();
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>Add New Plant</Text>

      <Pressable 
        style={({ pressed }) => [
          styles.imagePicker, 
          image && styles.imagePickerSelected,
          pressed && styles.buttonPressed
        ]}
        onPress={pickImage}
        disabled={loading}
      >
        <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
          {image ? (
            <Image source={{ uri: image }} style={styles.image} />
          ) : (
            <View style={styles.imagePlaceholder}>
              <Ionicons name="camera" size={40} color="#81c784" />
              <Text style={styles.imageText}>Add Plant Photo</Text>
            </View>
          )}
        </Animated.View>
      </Pressable>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Plant Name *</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Fiddle Leaf Fig"
          value={plantName}
          onChangeText={setPlantName}
          editable={!loading}
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Watering Frequency (days) *</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. 7"
          keyboardType="numeric"
          value={wateringFrequency}
          onChangeText={setWateringFrequency}
          editable={!loading}
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Plant Type</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Indoor, Succulent, Flowering"
          value={plantType}
          onChangeText={setPlantType}
          editable={!loading}
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Location</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Living Room, Balcony"
          value={location}
          onChangeText={setLocation}
          editable={!loading}
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Planting Date</Text>
        <Pressable 
          style={({ pressed }) => [
            styles.dateButton,
            pressed && styles.buttonPressed
          ]}
          onPress={showDatePicker}
          disabled={loading}
        >
          <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
            <Ionicons name="calendar" size={20} color="#4caf50" style={styles.dateIcon} />
            <Text style={styles.dateButtonText}>{plantDate.toDateString()}</Text>
          </Animated.View>
        </Pressable>
      </View>

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleConfirmDate}
        onCancel={hideDatePicker}
      />

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Notes</Text>
        <TextInput
          style={[styles.input, styles.notesInput]}
          placeholder="Add any special care instructions or notes"
          value={notes}
          onChangeText={setNotes}
          multiline
          numberOfLines={4}
          editable={!loading}
        />
      </View>

      <View style={styles.reminderRow}>
        <View style={styles.reminderTextContainer}>
          <Text style={styles.label}>Set Reminder</Text>
          <Text style={styles.reminderSubtext}>Get notified when it's time to water</Text>
        </View>
        <Switch
          value={reminder}
          onValueChange={(value) => setReminder(value)}
          thumbColor={reminder ? "#81c784" : "#ccc"}
          trackColor={{ false: "#f0f0f0", true: "#e8f5e9" }}
          disabled={loading}
        />
      </View>

      <Pressable
        style={({ pressed }) => [
          styles.saveButton,
          loading && styles.buttonDisabled,
          pressed && styles.buttonPressed
        ]}
        onPress={handleAddPlant}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.saveButtonText}>Save Plant</Text>
        )}
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: '#fdfdfd' 
  },
  title: { 
    fontSize: 28, 
    fontWeight: '700', 
    marginBottom: 20, 
    color: '#333', 
    alignSelf: 'center' 
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: { 
    fontSize: 16, 
    color: '#555', 
    marginBottom: 8,
    fontWeight: '500'
  },
  input: { 
    borderWidth: 1, 
    borderColor: '#ddd', 
    borderRadius: 12, 
    padding: 15, 
    backgroundColor: '#fff',
    fontSize: 16,
  },
  notesInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  button: { 
    backgroundColor: '#81c784', 
    padding: 15, 
    borderRadius: 30, 
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
    marginBottom: 30,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 3,
  },
  buttonText: { 
    color: '#fff', 
    fontSize: 18,
    fontWeight: '600',
  },
  buttonIcon: {
    marginRight: 8,
  },
  imagePicker: { 
    backgroundColor: '#f0f0f0', 
    height: 200, 
    borderRadius: 16, 
    marginBottom: 20, 
    justifyContent: 'center', 
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#ddd',
    borderStyle: 'dashed',
  },
  imagePickerSelected: {
    borderStyle: 'solid',
    borderColor: '#81c784',
  },
  image: { 
    width: '100%', 
    height: '100%', 
    borderRadius: 16 
  },
  imagePlaceholder: {
    alignItems: 'center',
  },
  imageText: { 
    color: '#555',
    marginTop: 10,
    fontSize: 16,
  },
  dateButton: { 
    backgroundColor: '#e8f5e9', 
    padding: 15, 
    borderRadius: 12, 
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  dateIcon: {
    marginRight: 8,
  },
  dateButtonText: { 
    fontSize: 16, 
    color: '#4caf50',
    fontWeight: '500',
  },
  reminderRow: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: 20,
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#eee',
  },
  reminderTextContainer: {
    flex: 1,
  },
  reminderSubtext: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  buttonPressed: {
    transform: [{ scale: 0.95 }],
    opacity: 0.8,
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  saveButton: {
    backgroundColor: '#81c784',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
});
